import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type InsertSubscription } from "@shared/routes";

export function useSubscription() {
  return useQuery({
    queryKey: [api.subscriptions.get.path],
    queryFn: async () => {
      const res = await fetch(api.subscriptions.get.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch subscription");
      return await res.json();
    },
  });
}

export function useCreateSubscription() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertSubscription) => {
      const res = await fetch(api.subscriptions.create.path, {
        method: api.subscriptions.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to create subscription");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.subscriptions.get.path] }),
  });
}
