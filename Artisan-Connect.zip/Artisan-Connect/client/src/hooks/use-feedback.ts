import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertFeedback, type FeedbackResponse } from "@shared/routes";
import { parseZodWithLog } from "@/lib/utils";

export function useFeedback(productId: number) {
  return useQuery({
    queryKey: [api.feedback.list.path, productId],
    queryFn: async () => {
      const url = buildUrl(api.feedback.list.path, { productId });
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch feedback");
      const data = await res.json();
      return parseZodWithLog<FeedbackResponse[]>(api.feedback.list.responses[200], data, "feedback.list");
    },
    enabled: !!productId,
  });
}

export function useCreateFeedback() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ productId, ...data }: Omit<InsertFeedback, "productId"> & { productId: number }) => {
      const url = buildUrl(api.feedback.create.path, { productId });
      const res = await fetch(url, {
        method: api.feedback.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 401) throw new Error("Please login to leave feedback");
        throw new Error("Failed to submit feedback");
      }
      return await res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.feedback.list.path, variables.productId] });
    },
  });
}
