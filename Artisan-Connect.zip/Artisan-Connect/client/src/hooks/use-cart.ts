import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertCartItem, type CartResponse } from "@shared/routes";
import { parseZodWithLog } from "@/lib/utils";

export function useCart() {
  return useQuery({
    queryKey: [api.cart.list.path],
    queryFn: async () => {
      const res = await fetch(api.cart.list.path, { credentials: "include" });
      if (res.status === 401) return []; // Not logged in means empty cart
      if (!res.ok) throw new Error("Failed to fetch cart");
      const data = await res.json();
      return parseZodWithLog<CartResponse[]>(api.cart.list.responses[200], data, "cart.list");
    },
  });
}

export function useAddToCart() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertCartItem) => {
      const res = await fetch(api.cart.add.path, {
        method: api.cart.add.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
        credentials: "include",
      });
      if (!res.ok) {
        if (res.status === 401) throw new Error("Please login to add to cart");
        throw new Error("Failed to add to cart");
      }
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.cart.list.path] }),
  });
}

export function useUpdateCartItem() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async ({ id, quantity }: { id: number; quantity: number }) => {
      const url = buildUrl(api.cart.update.path, { id });
      const res = await fetch(url, {
        method: api.cart.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ quantity }),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update cart item");
      return await res.json();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.cart.list.path] }),
  });
}

export function useRemoveFromCart() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (id: number) => {
      const url = buildUrl(api.cart.remove.path, { id });
      const res = await fetch(url, {
        method: api.cart.remove.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to remove item");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.cart.list.path] }),
  });
}

export function useClearCart() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      const res = await fetch(api.cart.clear.path, {
        method: api.cart.clear.method,
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to clear cart");
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.cart.list.path] }),
  });
}
