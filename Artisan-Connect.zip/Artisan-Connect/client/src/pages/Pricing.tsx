import { useAuth } from "@/hooks/use-auth";
import { useSubscription, useCreateSubscription } from "@/hooks/use-subscriptions";
import { Check, Star, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useLocation } from "wouter";

export default function Pricing() {
  const { user, isLoading: authLoading } = useAuth();
  const { data: subscription, isLoading: subLoading } = useSubscription();
  const createSub = useCreateSubscription();
  const [, setLocation] = useLocation();

  if (authLoading || subLoading) {
    return <div className="min-h-screen flex justify-center items-center"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>;
  }

  const handleSubscribe = (plan: "basic" | "premium") => {
    if (!user) {
      window.location.href = "/api/login";
      return;
    }
    createSub.mutate({ plan }, {
      onSuccess: () => setLocation("/dashboard")
    });
  };

  return (
    <div className="min-h-screen pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
      <div className="text-center max-w-3xl mx-auto mb-16">
        <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">Become an ArtiZen Artisan</h1>
        <p className="text-xl text-muted-foreground">
          Join our curated marketplace to share your cultural heritage and authentic craftsmanship with the world.
        </p>
      </div>

      {subscription?.status === 'active' && (
        <div className="mb-12 bg-primary/10 border border-primary/20 p-6 rounded-2xl text-center max-w-2xl mx-auto">
          <p className="text-lg font-bold text-primary mb-2">You are currently subscribed to the {subscription.plan} plan!</p>
          <button onClick={() => setLocation("/dashboard")} className="btn-primary mt-4">Go to Dashboard</button>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        {/* Basic Plan */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          className="bg-card p-8 rounded-3xl border border-border shadow-xl flex flex-col"
        >
          <h2 className="text-2xl font-display font-bold mb-2">Basic Artisan</h2>
          <p className="text-muted-foreground mb-6">Perfect for individual makers starting their digital journey.</p>
          <div className="mb-8">
            <span className="text-5xl font-bold">₹999</span>
            <span className="text-muted-foreground">/month</span>
          </div>
          <ul className="space-y-4 mb-8 flex-1">
            {["List up to 50 products", "Standard marketplace visibility", "Basic analytics dashboard", "Standard support"].map(f => (
              <li key={f} className="flex items-center gap-3">
                <Check className="w-5 h-5 text-primary" />
                <span className="font-medium text-foreground/80">{f}</span>
              </li>
            ))}
          </ul>
          <button 
            onClick={() => handleSubscribe("basic")} 
            disabled={createSub.isPending || subscription?.plan === "basic"}
            className="w-full btn-outline py-4"
          >
            {createSub.isPending ? "Processing..." : subscription?.plan === "basic" ? "Current Plan" : "Choose Basic"}
          </button>
        </motion.div>

        {/* Premium Plan */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-foreground text-background p-8 rounded-3xl border border-foreground shadow-2xl flex flex-col relative overflow-hidden"
        >
          <div className="absolute top-6 right-6 text-accent flex items-center gap-1 font-bold bg-accent/20 px-3 py-1 rounded-full text-xs">
            <Star className="w-4 h-4" /> Recommended
          </div>
          <h2 className="text-2xl font-display font-bold mb-2 text-background">Master Artisan</h2>
          <p className="text-background/70 mb-6">For established workshops and collectives.</p>
          <div className="mb-8">
            <span className="text-5xl font-bold">₹2499</span>
            <span className="text-background/70">/month</span>
          </div>
          <ul className="space-y-4 mb-8 flex-1">
            {["Unlimited product listings", "Priority placement in search", "Advanced sales analytics", "Dedicated success manager", "Featured on homepage"].map(f => (
              <li key={f} className="flex items-center gap-3">
                <Check className="w-5 h-5 text-accent" />
                <span className="font-medium text-background/90">{f}</span>
              </li>
            ))}
          </ul>
          <button 
            onClick={() => handleSubscribe("premium")} 
            disabled={createSub.isPending || subscription?.plan === "premium"}
            className="w-full btn-primary bg-accent text-accent-foreground hover:bg-accent/90 py-4 shadow-accent/20"
          >
            {createSub.isPending ? "Processing..." : subscription?.plan === "premium" ? "Current Plan" : "Choose Premium"}
          </button>
        </motion.div>
      </div>
    </div>
  );
}
