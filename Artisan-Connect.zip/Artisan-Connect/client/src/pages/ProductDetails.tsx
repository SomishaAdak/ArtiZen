import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { ShoppingBag, ArrowLeft, Star, Loader2, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";
import { useProduct } from "@/hooks/use-products";
import { useAddToCart } from "@/hooks/use-cart";
import { useFeedback, useCreateFeedback } from "@/hooks/use-feedback";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency } from "@/lib/utils";

export default function ProductDetails() {
  const { id } = useParams();
  const productId = parseInt(id || "0", 10);
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  
  const { data: product, isLoading: productLoading } = useProduct(productId);
  const { data: feedback, isLoading: feedbackLoading } = useFeedback(productId);
  
  const addToCart = useAddToCart();
  const createFeedback = useCreateFeedback();

  const [quantity, setQuantity] = useState(1);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");

  if (productLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
        <h2 className="text-3xl font-display font-bold mb-4">Product Not Found</h2>
        <button onClick={() => setLocation("/")} className="btn-primary">Return to Shop</button>
      </div>
    );
  }

  const handleAddToCart = () => {
    if (!user) {
      window.location.href = "/api/login";
      return;
    }
    addToCart.mutate({ productId, quantity });
  };

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    createFeedback.mutate({ productId, rating, comment }, {
      onSuccess: () => {
        setComment("");
        setRating(5);
      }
    });
  };

  return (
    <div className="min-h-screen pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-8">
      <button 
        onClick={() => setLocation("/")} 
        className="flex items-center gap-2 text-muted-foreground hover:text-primary mb-8 transition-colors font-medium"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Marketplace
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20">
        {/* Image Gallery */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="rounded-3xl overflow-hidden bg-card border border-border/50 shadow-xl aspect-square relative"
        >
          <img 
            src={product.imageUrl} 
            alt={product.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute top-6 left-6 bg-background/90 backdrop-blur-sm px-4 py-2 rounded-xl text-sm font-bold tracking-wide text-foreground uppercase shadow-lg">
            {product.category}
          </div>
        </motion.div>

        {/* Product Info */}
        <motion.div 
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex flex-col"
        >
          <div className="mb-2 flex items-center gap-2">
            <span className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Artisan crafted by</span>
            <span className="text-sm font-bold text-primary">{product.artisan?.firstName || "Traditional Maker"}</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl font-display font-bold text-foreground mb-4 leading-tight">
            {product.title}
          </h1>
          
          <div className="text-3xl font-bold text-foreground mb-8">
            {formatCurrency(product.price)}
          </div>

          <div className="prose prose-lg text-muted-foreground mb-10">
            <p>{product.description}</p>
          </div>

          <div className="mt-auto space-y-6 bg-card p-8 rounded-3xl border border-border/50 shadow-lg">
            <div className="flex items-center gap-4">
              <label className="font-bold text-foreground">Quantity:</label>
              <div className="flex items-center bg-background border border-border rounded-xl">
                <button 
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 py-2 hover:bg-muted text-foreground transition-colors rounded-l-xl"
                >-</button>
                <span className="w-12 text-center font-bold">{quantity}</span>
                <button 
                  onClick={() => setQuantity(quantity + 1)}
                  className="px-4 py-2 hover:bg-muted text-foreground transition-colors rounded-r-xl"
                >+</button>
              </div>
            </div>

            <button 
              onClick={handleAddToCart}
              disabled={addToCart.isPending}
              className="w-full btn-primary py-4 text-lg"
            >
              {addToCart.isPending ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : addToCart.isSuccess ? (
                <><CheckCircle2 className="w-6 h-6 mr-2" /> Added to Cart</>
              ) : (
                <><ShoppingBag className="w-6 h-6 mr-2" /> Add to Cart</>
              )}
            </button>
            {!user && (
              <p className="text-center text-sm text-muted-foreground mt-2">
                You will be asked to sign in to continue.
              </p>
            )}
          </div>
        </motion.div>
      </div>

      {/* Feedback Section */}
      <div className="border-t border-border pt-16">
        <h2 className="text-3xl font-display font-bold mb-10">Artisan Feedback</h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* List Feedback */}
          <div className="lg:col-span-2 space-y-6">
            {feedbackLoading ? (
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            ) : feedback?.length === 0 ? (
              <div className="bg-card p-8 rounded-2xl border border-border/50 text-center">
                <p className="text-muted-foreground">Be the first to review this magnificent piece.</p>
              </div>
            ) : (
              feedback?.map((fb) => (
                <div key={fb.id} className="bg-card p-6 rounded-2xl border border-border/50 shadow-sm">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-bold text-primary">
                        {fb.user?.firstName?.[0] || 'U'}
                      </div>
                      <div>
                        <p className="font-bold text-foreground">{fb.user?.firstName || 'Anonymous User'}</p>
                        <p className="text-xs text-muted-foreground">{new Date(fb.createdAt || '').toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="flex text-secondary">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`w-4 h-4 ${i < fb.rating ? 'fill-current' : 'text-muted'}`} />
                      ))}
                    </div>
                  </div>
                  <p className="text-muted-foreground">{fb.comment}</p>
                </div>
              ))
            )}
          </div>

          {/* Leave Feedback Form */}
          <div>
            {user ? (
              <form onSubmit={handleFeedbackSubmit} className="bg-card p-6 rounded-2xl border border-border/50 shadow-lg sticky top-24">
                <h3 className="font-display font-bold text-xl mb-6">Leave a Review</h3>
                
                <div className="mb-6">
                  <label className="block text-sm font-bold mb-2">Rating</label>
                  <div className="flex gap-2 text-secondary">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button 
                        key={star} 
                        type="button"
                        onClick={() => setRating(star)}
                        className="hover:scale-110 transition-transform"
                      >
                        <Star className={`w-8 h-8 ${star <= rating ? 'fill-current' : 'text-muted/50'}`} />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block text-sm font-bold mb-2">Your Thoughts</label>
                  <textarea 
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    required
                    className="input-styled min-h-[120px] resize-none"
                    placeholder="Tell us what you loved about this piece..."
                  />
                </div>

                <button 
                  type="submit" 
                  disabled={createFeedback.isPending}
                  className="w-full btn-primary"
                >
                  {createFeedback.isPending ? "Submitting..." : "Submit Review"}
                </button>
              </form>
            ) : (
              <div className="bg-card p-8 rounded-2xl border border-border/50 shadow-lg text-center">
                <h3 className="font-display font-bold text-xl mb-4">Want to leave a review?</h3>
                <p className="text-muted-foreground mb-6">Sign in to share your thoughts with the artisan.</p>
                <a href="/api/login" className="btn-outline w-full">Sign In</a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
