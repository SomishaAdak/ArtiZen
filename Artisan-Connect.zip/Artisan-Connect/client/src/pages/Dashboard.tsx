import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useProducts, useCreateProduct, useUpdateProduct, useDeleteProduct } from "@/hooks/use-products";
import { useSubscription } from "@/hooks/use-subscriptions";
import { Loader2, Plus, Edit2, Trash2, X } from "lucide-react";
import { Link, useLocation } from "wouter";
import { formatCurrency } from "@/lib/utils";

export default function Dashboard() {
  const { user, isLoading: authLoading } = useAuth();
  const { data: subscription, isLoading: subLoading } = useSubscription();
  const { data: allProducts, isLoading: prodLoading } = useProducts();
  const [, setLocation] = useLocation();
  
  const createProduct = useCreateProduct();
  const updateProduct = useUpdateProduct();
  const deleteProduct = useDeleteProduct();

  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    priceString: "",
    category: "Textiles",
    imageUrl: ""
  });

  if (authLoading || subLoading || prodLoading) {
    return <div className="min-h-screen flex justify-center items-center"><Loader2 className="w-12 h-12 animate-spin text-primary" /></div>;
  }

  if (!user) {
    window.location.href = "/api/login";
    return null;
  }

  if (!subscription || subscription.status !== 'active') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 text-center">
        <h2 className="text-4xl font-display font-bold mb-4">Artisan Dashboard</h2>
        <p className="text-xl text-muted-foreground mb-8 max-w-lg">
          To start listing your beautiful creations, you need an active artisan subscription.
        </p>
        <Link href="/pricing" className="btn-primary text-lg px-8 py-4">View Subscription Plans</Link>
      </div>
    );
  }

  // Filter products for logged in artisan (Mock logic - in reality backend should have /api/products/my)
  const myProducts = allProducts?.filter(p => p.artisanId === user.id) || [];

  const handleOpenNew = () => {
    setEditingId(null);
    setFormData({ title: "", description: "", priceString: "", category: "Textiles", imageUrl: "" });
    setIsFormOpen(true);
  };

  const handleOpenEdit = (p: any) => {
    setEditingId(p.id);
    setFormData({
      title: p.title,
      description: p.description,
      priceString: (p.price / 100).toString(),
      category: p.category,
      imageUrl: p.imageUrl
    });
    setIsFormOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const priceCents = Math.round(parseFloat(formData.priceString) * 100);
    
    const payload = {
      title: formData.title,
      description: formData.description,
      price: priceCents,
      category: formData.category,
      imageUrl: formData.imageUrl
    };

    if (editingId) {
      updateProduct.mutate({ id: editingId, ...payload }, {
        onSuccess: () => setIsFormOpen(false)
      });
    } else {
      createProduct.mutate(payload, {
        onSuccess: () => setIsFormOpen(false)
      });
    }
  };

  return (
    <div className="min-h-screen pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 relative">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-10 gap-4">
        <div>
          <h1 className="text-4xl font-display font-bold mb-2">Your Dashboard</h1>
          <p className="text-muted-foreground">Manage your artisan portfolio and store</p>
        </div>
        <button onClick={handleOpenNew} className="btn-primary whitespace-nowrap">
          <Plus className="w-5 h-5 mr-2" /> Add Creation
        </button>
      </div>

      {myProducts.length === 0 ? (
        <div className="bg-card border border-border/50 rounded-3xl p-16 text-center shadow-sm">
          <h3 className="text-2xl font-display font-bold mb-2">No products yet</h3>
          <p className="text-muted-foreground mb-6">Share your first masterpiece with the world.</p>
          <button onClick={handleOpenNew} className="btn-outline">Create Listing</button>
        </div>
      ) : (
        <div className="bg-card border border-border/50 rounded-3xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-muted/50 text-muted-foreground text-sm uppercase tracking-wider">
                  <th className="p-4 font-bold">Item</th>
                  <th className="p-4 font-bold">Category</th>
                  <th className="p-4 font-bold">Price</th>
                  <th className="p-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/50">
                {myProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-muted/20 transition-colors">
                    <td className="p-4">
                      <div className="flex items-center gap-4">
                        <img src={p.imageUrl} alt="" className="w-12 h-12 rounded-lg object-cover bg-muted" />
                        <span className="font-bold text-foreground">{p.title}</span>
                      </div>
                    </td>
                    <td className="p-4 text-muted-foreground">{p.category}</td>
                    <td className="p-4 font-bold">{formatCurrency(p.price)}</td>
                    <td className="p-4">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => handleOpenEdit(p)} className="p-2 text-muted-foreground hover:text-primary transition-colors bg-background rounded-lg border border-border shadow-sm">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => {
                            if(confirm("Are you sure you want to delete this item?")) deleteProduct.mutate(p.id);
                          }}
                          className="p-2 text-muted-foreground hover:text-destructive transition-colors bg-background rounded-lg border border-border shadow-sm"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Product Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
          <div className="bg-card w-full max-w-2xl rounded-3xl shadow-2xl border border-border/50 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-border/50 flex justify-between items-center bg-muted/30">
              <h2 className="text-2xl font-display font-bold">{editingId ? "Edit Creation" : "Add New Creation"}</h2>
              <button onClick={() => setIsFormOpen(false)} className="p-2 hover:bg-background rounded-full transition-colors">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1">
              <form id="productForm" onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="block text-sm font-bold mb-2">Title</label>
                  <input type="text" required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="input-styled" placeholder="e.g. Handwoven Silk Saree" />
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-bold mb-2">Price (INR)</label>
                    <input type="number" step="0.01" min="1" required value={formData.priceString} onChange={e => setFormData({...formData, priceString: e.target.value})} className="input-styled" placeholder="4500.00" />
                  </div>
                  <div>
                    <label className="block text-sm font-bold mb-2">Category</label>
                    <select required value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="input-styled">
                      <option value="Textiles">Textiles</option>
                      <option value="Pottery">Pottery</option>
                      <option value="Jewelry">Jewelry</option>
                      <option value="Woodwork">Woodwork</option>
                      <option value="Paintings">Paintings</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Image URL</label>
                  <input type="url" required value={formData.imageUrl} onChange={e => setFormData({...formData, imageUrl: e.target.value})} className="input-styled" placeholder="https://images.unsplash.com/..." />
                  <p className="text-xs text-muted-foreground mt-2">Please provide a direct link to an image of your item.</p>
                </div>

                <div>
                  <label className="block text-sm font-bold mb-2">Description</label>
                  <textarea required value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="input-styled min-h-[120px] resize-none" placeholder="Tell the story behind this piece..." />
                </div>
              </form>
            </div>
            
            <div className="p-6 border-t border-border/50 flex justify-end gap-4 bg-muted/30">
              <button type="button" onClick={() => setIsFormOpen(false)} className="btn-outline">Cancel</button>
              <button type="submit" form="productForm" disabled={createProduct.isPending || updateProduct.isPending} className="btn-primary">
                {createProduct.isPending || updateProduct.isPending ? "Saving..." : "Save Listing"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
