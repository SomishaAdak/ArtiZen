import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Search, Loader2, IndianRupee, ArrowRight, Filter, Store } from "lucide-react";
import { useProducts } from "@/hooks/use-products";
import { formatCurrency } from "@/lib/utils";

const CATEGORIES = ["All", "Textiles", "Pottery", "Jewelry", "Woodwork", "Paintings"];

export default function Home() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const { data: products, isLoading } = useProducts(search, category === "All" ? undefined : category);

  return (
    <div className="min-h-screen pb-24">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-foreground text-background py-24 sm:py-32">
        {/* landing page hero scenic indian cultural textiles */}
        <div className="absolute inset-0 opacity-40 mix-blend-overlay">
          <img 
            src="https://pixabay.com/get/ge21409a4c509d0522694ab3d1d63dd24717211164e608605115f654f57888396234039fc8aef7d91da53ba294cc1cad72e14c2b0840eba0b502e68d6c985b3c0_1280.jpg" 
            alt="Indian Textiles" 
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-foreground to-transparent opacity-80" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-5xl md:text-7xl font-display font-bold mb-6 text-background"
          >
            Preserving India's <span className="text-primary italic">Heritage</span>
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-lg md:text-xl text-background/80 max-w-2xl mx-auto mb-10"
          >
            Discover authentic, handmade treasures directly from traditional artisans across the subcontinent.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="max-w-xl mx-auto relative flex items-center"
          >
            <Search className="absolute left-4 w-5 h-5 text-muted-foreground" />
            <input 
              type="text" 
              placeholder="Search for textiles, pottery, jewelry..." 
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-12 pr-4 py-4 rounded-2xl bg-card text-card-foreground focus:outline-none focus:ring-4 focus:ring-primary/50 shadow-2xl"
            />
          </motion.div>
        </div>
      </section>

      {/* Categories */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-20">
        <div className="bg-card p-4 rounded-2xl shadow-xl shadow-black/5 border border-border/50 flex items-center gap-4 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-2 text-muted-foreground font-medium px-4 border-r border-border">
            <Filter className="w-5 h-5" /> Filters
          </div>
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`whitespace-nowrap px-6 py-2 rounded-xl font-medium transition-all ${
                category === cat 
                  ? "bg-primary text-primary-foreground shadow-md shadow-primary/20" 
                  : "bg-muted/50 text-muted-foreground hover:bg-primary/10 hover:text-primary"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>

      {/* Product Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16">
        <div className="flex items-center justify-between mb-10">
          <h2 className="text-3xl font-display font-bold">Featured Creations</h2>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center py-32">
            <Loader2 className="w-10 h-10 animate-spin text-primary" />
          </div>
        ) : products?.length === 0 ? (
          <div className="text-center py-20 bg-card rounded-3xl border border-border/50">
            <Store className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <h3 className="text-2xl font-display font-bold mb-2">No items found</h3>
            <p className="text-muted-foreground">Try adjusting your search or category filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
            {products?.map((product, i) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: i * 0.05 }}
              >
                <Link href={`/products/${product.id}`} className="group block bg-card rounded-2xl overflow-hidden border border-border/50 shadow-sm hover:shadow-xl hover:border-primary/20 transition-all duration-300 h-full flex flex-col">
                  <div className="aspect-[4/3] overflow-hidden relative bg-muted">
                    <img 
                      src={product.imageUrl} 
                      alt={product.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute top-3 left-3 bg-background/90 backdrop-blur-sm px-3 py-1 rounded-lg text-xs font-bold tracking-wide text-foreground uppercase">
                      {product.category}
                    </div>
                  </div>
                  <div className="p-5 flex flex-col flex-1">
                    <div className="flex justify-between items-start mb-2 gap-4">
                      <h3 className="font-display font-bold text-lg leading-tight group-hover:text-primary transition-colors">
                        {product.title}
                      </h3>
                      <p className="font-bold text-primary whitespace-nowrap">
                        {formatCurrency(product.price)}
                      </p>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                      {product.description}
                    </p>
                    <div className="mt-auto flex items-center justify-between">
                      <p className="text-xs text-muted-foreground font-medium">
                        By {product.artisan?.firstName || "Artisan"}
                      </p>
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
