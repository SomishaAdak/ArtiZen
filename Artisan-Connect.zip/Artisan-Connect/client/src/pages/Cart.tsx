import { useCart, useUpdateCartItem, useRemoveFromCart, useClearCart } from "@/hooks/use-cart";
import { useAuth } from "@/hooks/use-auth";
import { formatCurrency } from "@/lib/utils";
import { ShoppingBag, Trash2, ArrowRight, Minus, Plus, Loader2 } from "lucide-react";
import { Link } from "wouter";

export default function Cart() {
  const { user, isLoading: authLoading } = useAuth();
  const { data: cartItems, isLoading: cartLoading } = useCart();
  const updateItem = useUpdateCartItem();
  const removeItem = useRemoveFromCart();
  const clearCart = useClearCart();

  if (authLoading || cartLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center p-4">
        <div className="w-24 h-24 bg-primary/10 text-primary rounded-full flex items-center justify-center mb-6">
          <ShoppingBag className="w-12 h-12" />
        </div>
        <h2 className="text-3xl font-display font-bold mb-4">Your Cart is Waiting</h2>
        <p className="text-muted-foreground mb-8 max-w-md">Sign in to add beautiful artisan creations to your collection.</p>
        <a href="/api/login" className="btn-primary">Sign In to Continue</a>
      </div>
    );
  }

  const subtotal = cartItems?.reduce((total, item) => total + (item.product.price * item.quantity), 0) || 0;
  const shipping = subtotal > 0 ? 5000 : 0; // $50 flat shipping for example
  const total = subtotal + shipping;

  return (
    <div className="min-h-screen pb-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12">
      <h1 className="text-4xl font-display font-bold mb-10">Your Collection</h1>

      {cartItems?.length === 0 ? (
        <div className="bg-card rounded-3xl p-12 text-center border border-border/50 shadow-sm">
          <ShoppingBag className="w-16 h-16 text-muted-foreground/30 mx-auto mb-6" />
          <h2 className="text-2xl font-bold mb-4">Your cart is empty</h2>
          <p className="text-muted-foreground mb-8">Discover unique treasures crafted by master artisans.</p>
          <Link href="/" className="btn-primary">Browse Marketplace</Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-6">
            {cartItems?.map((item) => (
              <div key={item.id} className="bg-card p-4 sm:p-6 rounded-2xl border border-border/50 shadow-sm flex flex-col sm:flex-row gap-6 items-start sm:items-center">
                <div className="w-full sm:w-32 h-32 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                  <img src={item.product.imageUrl} alt={item.product.title} className="w-full h-full object-cover" />
                </div>
                
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-2">
                    <Link href={`/products/${item.productId}`} className="font-display font-bold text-xl hover:text-primary transition-colors">
                      {item.product.title}
                    </Link>
                    <p className="font-bold text-lg">{formatCurrency(item.product.price)}</p>
                  </div>
                  <p className="text-sm text-muted-foreground mb-6">{item.product.category}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex items-center bg-background border border-border rounded-lg overflow-hidden">
                      <button 
                        onClick={() => {
                          if (item.quantity > 1) {
                            updateItem.mutate({ id: item.id, quantity: item.quantity - 1 });
                          } else {
                            removeItem.mutate(item.id);
                          }
                        }}
                        disabled={updateItem.isPending}
                        className="p-2 hover:bg-muted transition-colors disabled:opacity-50"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-10 text-center font-bold text-sm">{item.quantity}</span>
                      <button 
                        onClick={() => updateItem.mutate({ id: item.id, quantity: item.quantity + 1 })}
                        disabled={updateItem.isPending}
                        className="p-2 hover:bg-muted transition-colors disabled:opacity-50"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                    
                    <button 
                      onClick={() => removeItem.mutate(item.id)}
                      disabled={removeItem.isPending}
                      className="text-muted-foreground hover:text-destructive flex items-center gap-2 text-sm font-medium transition-colors"
                    >
                      <Trash2 className="w-4 h-4" /> Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order Summary */}
          <div className="bg-card p-8 rounded-3xl border border-border/50 shadow-xl h-fit sticky top-24">
            <h2 className="font-display font-bold text-2xl mb-6">Order Summary</h2>
            
            <div className="space-y-4 mb-6 text-muted-foreground">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-medium text-foreground">{formatCurrency(subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span>Artisan Direct Shipping</span>
                <span className="font-medium text-foreground">{formatCurrency(shipping)}</span>
              </div>
            </div>
            
            <div className="border-t border-border pt-6 mb-8">
              <div className="flex justify-between items-end">
                <span className="font-bold text-lg">Total</span>
                <span className="font-bold text-3xl text-primary">{formatCurrency(total)}</span>
              </div>
              <p className="text-xs text-muted-foreground mt-2 text-right">Taxes calculated at checkout</p>
            </div>
            
            <button 
              className="w-full btn-primary py-4 text-lg mb-4"
              onClick={() => {
                alert("Proceeding to secure checkout...");
                clearCart.mutate();
              }}
              disabled={clearCart.isPending}
            >
              {clearCart.isPending ? <Loader2 className="w-6 h-6 animate-spin mx-auto" /> : "Secure Checkout"}
            </button>
            
            <Link href="/" className="w-full btn-outline flex justify-center py-3">
              Continue Shopping
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
