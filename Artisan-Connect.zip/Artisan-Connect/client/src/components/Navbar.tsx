import { Link } from "wouter";
import { ShoppingBag, Store, User as UserIcon, LogOut, Loader2, Compass } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useCart } from "@/hooks/use-cart";
import { motion } from "framer-motion";

export function Navbar() {
  const { user, isLoading, logout } = useAuth();
  const { data: cartItems } = useCart();
  
  const cartCount = cartItems?.reduce((sum, item) => sum + item.quantity, 0) || 0;

  return (
    <header className="sticky top-0 z-50 w-full glass-card border-b-0 border-t-0 border-l-0 border-r-0 rounded-none shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 group cursor-pointer">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
            <Store className="w-6 h-6" />
          </div>
          <span className="font-display font-bold text-2xl tracking-tight text-foreground">ArtiZen</span>
        </Link>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/" className="text-muted-foreground hover:text-primary font-medium transition-colors">Marketplace</Link>
          <Link href="/dashboard" className="text-muted-foreground hover:text-primary font-medium transition-colors">Artisan Dashboard</Link>
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-4">
          <Link href="/cart" className="relative p-2 text-muted-foreground hover:text-primary transition-colors cursor-pointer">
            <ShoppingBag className="w-6 h-6" />
            {cartCount > 0 && (
              <motion.span 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="absolute top-0 right-0 w-5 h-5 flex items-center justify-center bg-accent text-accent-foreground text-xs font-bold rounded-full border-2 border-card"
              >
                {cartCount}
              </motion.span>
            )}
          </Link>

          {isLoading ? (
            <Loader2 className="w-6 h-6 animate-spin text-primary/50" />
          ) : user ? (
            <div className="flex items-center gap-4 ml-2 border-l pl-4 border-border">
              <div className="hidden sm:flex items-center gap-3">
                {user.profileImageUrl ? (
                  <img src={user.profileImageUrl} alt="Profile" className="w-9 h-9 rounded-full border border-primary/20 object-cover" />
                ) : (
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-primary">
                    <UserIcon className="w-5 h-5" />
                  </div>
                )}
                <div className="flex flex-col">
                  <span className="text-sm font-bold leading-none">{user.firstName || 'User'}</span>
                  <span className="text-xs text-muted-foreground">{user.email}</span>
                </div>
              </div>
              <button 
                onClick={() => logout()}
                className="p-2 text-muted-foreground hover:text-destructive transition-colors rounded-lg hover:bg-destructive/10"
                title="Log out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          ) : (
            <a href="/api/login" className="btn-primary py-2 px-5 ml-2 text-sm">
              Sign In
            </a>
          )}
        </div>
      </div>
    </header>
  );
}
