## Packages
framer-motion | Page transitions and scroll-triggered animations
lucide-react | Icons for the UI
date-fns | Human-readable date formatting

## Notes
The application requires a warm, traditional Indian marketplace aesthetic.
We will use Playfair Display and DM Sans from Google Fonts.
Backend assumes price is stored in cents, so the frontend must format it to dollars.
Authentication is handled via Replit Auth (/api/login, /api/logout, and the useAuth hook).
