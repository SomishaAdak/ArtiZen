import { db } from "./db";
import { 
  products, cartItems, subscriptions, feedback, users,
  type InsertProduct, type InsertCartItem, type InsertSubscription, type InsertFeedback,
  type ProductWithArtisan, type FeedbackWithUser, type CartItem, type Subscription, type Product, type Feedback
} from "@shared/schema";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Products
  getProducts(search?: string, category?: string): Promise<ProductWithArtisan[]>;
  getProduct(id: number): Promise<ProductWithArtisan | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product>;
  deleteProduct(id: number): Promise<void>;

  // Cart
  getCart(userId: string): Promise<(CartItem & { product: Product })[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem>;
  removeFromCart(id: number): Promise<void>;
  clearCart(userId: string): Promise<void>;

  // Subscriptions
  getSubscription(userId: string): Promise<Subscription | undefined>;
  createSubscription(sub: InsertSubscription): Promise<Subscription>;

  // Feedback
  getFeedback(productId: number): Promise<FeedbackWithUser[]>;
  createFeedback(fb: InsertFeedback): Promise<Feedback>;
}

export class DatabaseStorage implements IStorage {
  async getProducts(search?: string, category?: string): Promise<ProductWithArtisan[]> {
    // Basic implementation, no complex search for now
    let query = db.select({
      id: products.id,
      artisanId: products.artisanId,
      title: products.title,
      description: products.description,
      price: products.price,
      imageUrl: products.imageUrl,
      category: products.category,
      createdAt: products.createdAt,
      artisan: users
    }).from(products)
    .leftJoin(users, eq(products.artisanId, users.id));

    // To properly support search and category we'd need dynamic query building, but let's keep it simple
    let results = await query;
    
    if (search) {
      const searchLower = search.toLowerCase();
      results = results.filter(r => r.title.toLowerCase().includes(searchLower) || r.description.toLowerCase().includes(searchLower));
    }
    
    if (category) {
      const catLower = category.toLowerCase();
      results = results.filter(r => r.category.toLowerCase() === catLower);
    }
    
    return results;
  }

  async getProduct(id: number): Promise<ProductWithArtisan | undefined> {
    const results = await db.select({
      id: products.id,
      artisanId: products.artisanId,
      title: products.title,
      description: products.description,
      price: products.price,
      imageUrl: products.imageUrl,
      category: products.category,
      createdAt: products.createdAt,
      artisan: users
    }).from(products)
    .leftJoin(users, eq(products.artisanId, users.id))
    .where(eq(products.id, id));

    return results[0];
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [created] = await db.insert(products).values(product).returning();
    return created;
  }

  async updateProduct(id: number, updates: Partial<InsertProduct>): Promise<Product> {
    const [updated] = await db.update(products).set(updates).where(eq(products.id, id)).returning();
    return updated;
  }

  async deleteProduct(id: number): Promise<void> {
    await db.delete(products).where(eq(products.id, id));
  }

  async getCart(userId: string): Promise<(CartItem & { product: Product })[]> {
    const items = await db.select({
      cartItem: cartItems,
      product: products
    }).from(cartItems)
    .innerJoin(products, eq(cartItems.productId, products.id))
    .where(eq(cartItems.userId, userId));
    
    return items.map(i => ({ ...i.cartItem, product: i.product }));
  }

  async addToCart(item: InsertCartItem & { userId: string }): Promise<CartItem> {
    const [existing] = await db.select().from(cartItems)
      .where(and(eq(cartItems.userId, item.userId), eq(cartItems.productId, item.productId)));

    if (existing) {
      const [updated] = await db.update(cartItems)
        .set({ quantity: existing.quantity + item.quantity })
        .where(eq(cartItems.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(cartItems).values(item).returning();
      return created;
    }
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem> {
    const [updated] = await db.update(cartItems).set({ quantity }).where(eq(cartItems.id, id)).returning();
    return updated;
  }

  async removeFromCart(id: number): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.id, id));
  }

  async clearCart(userId: string): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.userId, userId));
  }

  async getSubscription(userId: string): Promise<Subscription | undefined> {
    const [sub] = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId));
    return sub;
  }

  async createSubscription(sub: InsertSubscription & { userId: string }): Promise<Subscription> {
    // UPSERT
    const [existing] = await db.select().from(subscriptions).where(eq(subscriptions.userId, sub.userId));
    if (existing) {
      const [updated] = await db.update(subscriptions)
        .set({ plan: sub.plan, status: 'active' })
        .where(eq(subscriptions.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db.insert(subscriptions).values({ ...sub, status: 'active' }).returning();
      return created;
    }
  }

  async getFeedback(productId: number): Promise<FeedbackWithUser[]> {
    const results = await db.select({
      id: feedback.id,
      userId: feedback.userId,
      productId: feedback.productId,
      rating: feedback.rating,
      comment: feedback.comment,
      createdAt: feedback.createdAt,
      user: users
    }).from(feedback)
    .leftJoin(users, eq(feedback.userId, users.id))
    .where(eq(feedback.productId, productId));
    
    return results;
  }

  async createFeedback(fb: InsertFeedback & { userId: string }): Promise<Feedback> {
    const [created] = await db.insert(feedback).values(fb).returning();
    return created;
  }
}

export const storage = new DatabaseStorage();
