import { db } from "./db";
import { products, users } from "../shared/schema";

async function seed() {
  // Clear existing data and reseed with new artisans
  await db.delete(products);
  await db.delete(users);

  const artisans = [
    { id: "artisan-1", email: "priya.textiles@example.com", firstName: "Priya", lastName: "Devi" },
    { id: "artisan-2", email: "rajesh.pottery@example.com", firstName: "Rajesh", lastName: "Kumar" },
    { id: "artisan-3", email: "anaya.jewelry@example.com", firstName: "Anaya", lastName: "Singh" },
    { id: "artisan-4", email: "vikram.woodwork@example.com", firstName: "Vikram", lastName: "Sharma" },
    { id: "artisan-5", email: "meena.paintings@example.com", firstName: "Meena", lastName: "Nair" },
  ];

  // Insert artisans
  for (const artisan of artisans) {
    await db.insert(users).values(artisan);
  }

  console.log("Seeding traditional Indian artisan products...");
  
  // Insert products with traditional images
  await db.insert(products).values([
    // Textiles by Priya Devi
    {
      artisanId: "artisan-1",
      title: "Handwoven Banarasi Silk Saree",
      description: "Authentic Banarasi saree with traditional golden zari work and intricate brocade patterns. Each thread is hand-picked for quality.",
      price: 18000,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/0/07/Saree_IMG_3127.jpg/640px-Saree_IMG_3127.jpg",
      category: "Textiles"
    },
    {
      artisanId: "artisan-1",
      title: "Handwoven Cotton Dupatta",
      description: "Traditional cotton dupatta with natural vegetable dyes and block print patterns inspired by rural Rajasthan.",
      price: 2500,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/3/36/Handloom_dupatta.jpg/640px-Handloom_dupatta.jpg",
      category: "Textiles"
    },
    {
      artisanId: "artisan-1",
      title: "Ikat Silk Scarf",
      description: "Handcrafted Ikat weave scarf using indigo and natural dyes, following 500-year-old textile techniques from Odisha.",
      price: 3500,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/a/ab/Odisha_Ikat.jpg/640px-Odisha_Ikat.jpg",
      category: "Textiles"
    },
    // Pottery by Rajesh Kumar
    {
      artisanId: "artisan-2",
      title: "Hand-Thrown Terracotta Water Pitcher",
      description: "Traditional clay water pitcher handmade using ancient wheel-throwing techniques. Perfect for keeping water cool naturally.",
      price: 4500,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/2/25/Potter%27s_wheel_%28Dhaka%2C_Bangladesh%29.jpg/640px-Potter%27s_wheel_%28Dhaka%2C_Bangladesh%29.jpg",
      category: "Pottery"
    },
    {
      artisanId: "artisan-2",
      title: "Khurja Painted Pottery Bowl",
      description: "Hand-painted terracotta bowl from Khurja with traditional floral and geometric patterns in vibrant natural colors.",
      price: 2800,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/1/1f/Indian_pottery.jpg/640px-Indian_pottery.jpg",
      category: "Pottery"
    },
    {
      artisanId: "artisan-2",
      title: "Black Pottery Showpiece",
      description: "Traditional black pottery from Nizamabad crafted using ancient kiln-firing methods. Smooth polished finish.",
      price: 3800,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/4/46/Nizamabad_pottery.jpg/640px-Nizamabad_pottery.jpg",
      category: "Pottery"
    },
    // Jewelry by Anaya Singh
    {
      artisanId: "artisan-3",
      title: "Kundan Bridal Necklace Set",
      description: "Exquisite kundan jewelry with 22k gold backing, hand-set uncut diamonds and emeralds. Traditional bridal wear.",
      price: 32000,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/7/7c/Kundan_jewelry_work.jpg/640px-Kundan_jewelry_work.jpg",
      category: "Jewelry"
    },
    {
      artisanId: "artisan-3",
      title: "Meenakari Gold Pendant",
      description: "Hand-painted meenakari work with vibrant enamels on 22k gold. Showcases peacock motifs inspired by Mughal art.",
      price: 8500,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/e/eb/Meenakari_work_Jaipur.jpg/640px-Meenakari_work_Jaipur.jpg",
      category: "Jewelry"
    },
    {
      artisanId: "artisan-3",
      title: "Temple Jewelry Earrings",
      description: "Traditional temple gold plated earrings with intricate filigree work and semi-precious stones. Antique finish.",
      price: 5200,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/a/ad/South_Indian_temple_jewelry.jpg/640px-South_Indian_temple_jewelry.jpg",
      category: "Jewelry"
    },
    // Woodwork by Vikram Sharma
    {
      artisanId: "artisan-4",
      title: "Hand-Carved Teakwood Jewelry Box",
      description: "Exquisitely carved jewelry box from Jaipur with intricate floral and geometric patterns. Premium teak wood.",
      price: 9500,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/3/39/Carved_wooden_box.jpg/640px-Carved_wooden_box.jpg",
      category: "Woodwork"
    },
    {
      artisanId: "artisan-4",
      title: "Sandalwood Carving - Ganesha",
      description: "Hand-carved sandalwood deity sculpture with fine details. Releases natural fragrance. A spiritual decor piece.",
      price: 6800,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/6/6d/Sandalwood_carving.jpg/640px-Sandalwood_carving.jpg",
      category: "Woodwork"
    },
    {
      artisanId: "artisan-4",
      title: "Mughal-Style Wooden Mirror Frame",
      description: "Ornately carved wooden frame with inlay work inspired by Mughal architecture. Handcrafted from sheesham wood.",
      price: 7200,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/2/23/Wooden_mirror_frame.jpg/640px-Wooden_mirror_frame.jpg",
      category: "Woodwork"
    },
    // Paintings by Meena Nair
    {
      artisanId: "artisan-5",
      title: "Traditional Madhubani Painting on Canvas",
      description: "Authentic Madhubani art with intricate geometric patterns and mythological motifs using natural pigments.",
      price: 5500,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/c/c9/Madhubani_painting.jpg/640px-Madhubani_painting.jpg",
      category: "Paintings"
    },
    {
      artisanId: "artisan-5",
      title: "Warli Art Canvas - Village Life",
      description: "Hand-painted Warli tribal art depicting rural life and nature. Uses traditional white pigment on natural terracotta canvas.",
      price: 4200,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/d/d7/Warli_painting.jpg/640px-Warli_painting.jpg",
      category: "Paintings"
    },
    {
      artisanId: "artisan-5",
      title: "Tanjore Gold Leaf Painting",
      description: "Traditional Tanjore painting with 24k gold leaf on wooden base. Depicts a classical Hindu deity with ornate background.",
      price: 8900,
      imageUrl: "https://images.wikimedia.org/wikipedia/commons/thumb/8/8e/Tanjore_painting.jpg/640px-Tanjore_painting.jpg",
      category: "Paintings"
    }
  ]);

  console.log("Successfully seeded 15 products from 5 different artisans!");
}

seed().catch(console.error).finally(() => process.exit(0));
