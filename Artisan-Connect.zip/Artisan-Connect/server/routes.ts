import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, registerAuthRoutes, isAuthenticated } from "./replit_integrations/auth";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Set up authentication
  await setupAuth(app);
  registerAuthRoutes(app);

  // Products
  app.get(api.products.list.path, async (req, res) => {
    try {
      const { search, category } = req.query;
      const products = await storage.getProducts(search as string, category as string);
      res.json(products);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get(api.products.get.path, async (req, res) => {
    try {
      const product = await storage.getProduct(Number(req.params.id));
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.products.create.path, isAuthenticated, async (req: any, res) => {
    try {
      // Must be subscribed to create a product
      const sub = await storage.getSubscription(req.user.claims.sub);
      if (!sub || sub.status !== 'active') {
        return res.status(401).json({ message: "Must have an active subscription to list products" });
      }

      const input = api.products.create.input.parse({
        ...req.body,
        price: Number(req.body.price),
      });

      const product = await storage.createProduct({
        ...input,
        artisanId: req.user.claims.sub
      });

      res.status(201).json(product);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put(api.products.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const product = await storage.getProduct(Number(req.params.id));
      if (!product) return res.status(404).json({ message: "Product not found" });
      if (product.artisanId !== req.user.claims.sub) return res.status(401).json({ message: "Unauthorized" });

      const updates = api.products.update.input.parse({
        ...req.body,
        price: req.body.price ? Number(req.body.price) : undefined,
      });

      const updated = await storage.updateProduct(Number(req.params.id), updates);
      res.json(updated);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.products.delete.path, isAuthenticated, async (req: any, res) => {
    try {
      const product = await storage.getProduct(Number(req.params.id));
      if (!product) return res.status(404).json({ message: "Product not found" });
      if (product.artisanId !== req.user.claims.sub) return res.status(401).json({ message: "Unauthorized" });

      await storage.deleteProduct(Number(req.params.id));
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Cart
  app.get(api.cart.list.path, isAuthenticated, async (req: any, res) => {
    try {
      const cart = await storage.getCart(req.user.claims.sub);
      res.json(cart);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.cart.add.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.cart.add.input.parse(req.body);
      const item = await storage.addToCart({
        ...input,
        userId: req.user.claims.sub
      });
      res.status(201).json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.put(api.cart.update.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.cart.update.input.parse(req.body);
      const item = await storage.updateCartItem(Number(req.params.id), input.quantity);
      res.json(item);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.cart.remove.path, isAuthenticated, async (req: any, res) => {
    try {
      await storage.removeFromCart(Number(req.params.id));
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete(api.cart.clear.path, isAuthenticated, async (req: any, res) => {
    try {
      await storage.clearCart(req.user.claims.sub);
      res.status(204).end();
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Subscriptions
  app.get(api.subscriptions.get.path, isAuthenticated, async (req: any, res) => {
    try {
      const sub = await storage.getSubscription(req.user.claims.sub);
      res.json(sub || null);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.subscriptions.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.subscriptions.create.input.parse(req.body);
      const sub = await storage.createSubscription({
        ...input,
        userId: req.user.claims.sub
      });
      res.status(201).json(sub);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Feedback
  app.get(api.feedback.list.path, async (req, res) => {
    try {
      const list = await storage.getFeedback(Number(req.params.productId));
      res.json(list);
    } catch (err) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post(api.feedback.create.path, isAuthenticated, async (req: any, res) => {
    try {
      const input = api.feedback.create.input.parse(req.body);
      const fb = await storage.createFeedback({
        ...input,
        productId: Number(req.params.productId),
        userId: req.user.claims.sub
      });
      res.status(201).json(fb);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message, field: err.errors[0].path.join('.') });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  return httpServer;
}
